import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mychart',
  templateUrl: './mychart.component.html',
  styleUrls: ['./mychart.component.scss'],
})
export class MychartComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
